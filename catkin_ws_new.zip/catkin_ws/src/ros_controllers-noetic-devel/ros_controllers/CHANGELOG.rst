^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ros_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.21.1 (2023-01-31)
-------------------

0.21.0 (2022-10-21)
-------------------

0.20.0 (2022-05-06)
-------------------

0.19.0 (2021-06-13)
-------------------

0.18.1 (2020-12-03)
-------------------
* Update package.xml of ros_controllers meta-package to format 3
* Contributors: Mateus Amarante Araújo

0.18.0 (2020-10-11)
-------------------

0.17.0 (2020-05-12)
-------------------

0.16.1 (2020-04-27)
-------------------

0.16.0 (2020-04-16)
-------------------
* Bump CMake version to prevent CMP0048
* Contributors: Matt Reynolds

0.15.1 (2020-03-09)
-------------------
* Remove rqt_joint_trajectory_controller from metapackage (`#443 <https://github.com/ros-controls/ros_controllers/issues/443>`_)
* Contributors: Matt Reynolds

0.15.0 (2019-03-26)
-------------------

0.14.3 (2019-02-09)
-------------------
* Add ackermann_steering_controller (`#356 <https://github.com/ros-controls/ros_controllers/issues/356>`_)
* Contributors: Mori

0.14.2 (2018-10-23)
-------------------
* Update maintainers
* Contributors: Bence Magyar

0.14.1 (2018-06-26)
-------------------

0.14.0 (2018-04-27)
-------------------

0.13.2 (2017-12-23)
-------------------

0.13.1 (2017-11-06)
-------------------

0.13.0 (2017-08-10)
-------------------

0.12.3 (2017-04-23)
-------------------

0.12.2 (2017-04-21)
-------------------

0.12.1 (2017-03-08)
-------------------

0.12.0 (2017-02-15)
-------------------
* Ordered dependencies & cleanup
* Change for format2
* Add Enrique and Bence to maintainers
* Contributors: Bence Magyar

0.11.2 (2016-08-16)
-------------------

0.11.1 (2016-05-23)
-------------------

0.11.0 (2016-05-03)
-------------------

0.10.0 (2015-11-20)
-------------------

0.9.2 (2015-05-04)
------------------

0.9.1 (2014-11-03)
------------------
* Update package maintainers
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.9.0 (2014-10-31)
------------------
* Add rqt_joint_trajectory_controller to metapackage

0.8.1 (2014-07-11)
------------------

0.8.0 (2014-05-12)
------------------

0.7.2 (2014-04-01)
------------------

0.7.1 (2014-03-31)
------------------

0.7.0 (2014-03-28)
------------------
* Add diff_drive_controller and gripper_action_controller dependencies.
* Contributors: Adolfo Rodriguez Tsouroukdissian, Dave Coleman

0.6.0 (2014-02-05)
------------------
* Add self as ros_controllers maintainer.
* Contributors: Adolfo Rodriguez Tsouroukdissian

0.5.4 (2013-09-30)
------------------
* Add joint_trajectory_controller to metapackage.

0.5.3 (2013-09-04)
------------------

0.5.2 (2013-08-06)
------------------

0.5.1 (2013-07-16)
------------------
* Added to maintainer list

0.5.0 (2013-07-16)
------------------
* Added force_torque_sensor_controller
* Removed controller_msgs, switched to depend on control_msgs
* Added imu_sensor_controller
* Updates to effort_controllers


0.4.0 (2013-06-26)
------------------
* Initial release of ros_controllers into bloom/ROS distro
