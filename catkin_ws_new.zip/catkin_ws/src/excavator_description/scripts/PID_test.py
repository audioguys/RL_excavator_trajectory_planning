#! /usr/bin/env python


import rospy
import logging
import rospkg
from gazebo_msgs.srv import SpawnModel
from geometry_msgs.msg import Pose
import os
from sensor_msgs.msg import JointState
import time
import matplotlib.pyplot as plt
import numpy as np
import math
from std_msgs.msg import Float64



joint_positions = None

def joints_callback(data):
    global joint_positions
    joint_positions = data.position


def puber():
    stop_2 = False
    stop_1 = False
    stop_3 = False
    stop_4 = False
    pub_1 = rospy.Publisher('/excavator/joint_1_controller/command', Float64, queue_size=1)
    pub_2 = rospy.Publisher('/excavator/joint_2_controller/command', Float64, queue_size=1)
    pub_3 = rospy.Publisher('/excavator/joint_3_controller/command', Float64, queue_size=1)
    pub_4 = rospy.Publisher('/excavator/joint_4_controller/command', Float64, queue_size=1)
    rate = rospy.Rate(40)
    while not rospy.is_shutdown():
        if joint_positions[0] > -0.524:
            pub_1.publish(-0.05)
        else:
            pub_1.publish(0.0)
            stop_1 = True

        if joint_positions[1] < 0.1:
            pub_2.publish(0.1)
        else:
            pub_2.publish(0.0)
            stop_2 = True

        if joint_positions[2] < 0.8:
            pub_3.publish(0.1)
        else:
            pub_3.publish(0.0)
            stop_3 = True

        if joint_positions[3] > -1.5:
            pub_4.publish(-0.2)
        else:
            pub_4.publish(0.0)
            stop_4 = True
        if stop_1 and stop_2 and stop_3 and stop_4:
            break
        rate.sleep()
        

if __name__ == '__main__':

    rospy.init_node('move_to_dig')

    # Subscribe to the "/excavator/joint_states" topic
    rospy.Subscriber("/excavator/joint_states", JointState, joints_callback)

    rospy.sleep(0.5)
    # Print the joint positions from the global variable
    if joint_positions is not None:
        puber()
    print('Finish')

