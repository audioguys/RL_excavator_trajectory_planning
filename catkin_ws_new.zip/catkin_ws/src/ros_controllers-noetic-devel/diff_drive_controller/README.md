## Diff Drive Controller ##

Controller for a differential drive mobile base.

Detailed user documentation can be found in the controller's [ROS wiki page](http://wiki.ros.org/diff_drive_controller).
